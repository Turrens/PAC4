#include <iostream>
#include <thread>
#include <windows.h>
#include <chrono>
#include <cstdlib>
#include <ctime>
#include <mutex>
#include <vector>
#include <atomic>

using namespace std;

const int META = 50; // La meta ser� en 50 passos
mutex consoleMutex;
atomic<bool> haGuanyat(false); // Bandera per indicar si hi ha un guanyador

// Estructura per representar cada animal
struct Animal {
    string nom;
    int velocitatBase;
    int posicio;
    int fila;

    Animal(string n, int v, int f) : nom(n), velocitatBase(v), posicio(0), fila(f) {}
};

// Funci� per moure el cursor a una posici� espec�fica
void mouCursor(int x, int y) {
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    COORD pos = { static_cast<SHORT>(x), static_cast<SHORT>(y) };
    SetConsoleCursorPosition(hConsole, pos);
}

// Funci� que fa veure el moviment de cada animal
void correAnimal(Animal& animal) {
    srand(time(0) + animal.fila); // Inicialitza una llavor �nica per a cada fil
    while (animal.posicio < META && !haGuanyat.load()) { // Comprova si alg� ha guanyat
        // C�lcul de l'avan� aleatori
        int avan�ament = animal.velocitatBase + (rand() % 3 - 1); // Avan�ament entre velocitatBase-1 i velocitatBase+1
        avan�ament = max(0, avan�ament); // L'avan�ament no pot ser negatiu

        // Pauses aleat�ries
        if (rand() % 5 == 0) { // Un 20% de possibilitats de pausa
            avan�ament = 0;
        }

        // Actualitza la posici�
        animal.posicio += avan�ament;
        if (animal.posicio > META) animal.posicio = META;

        // Bloqueig per actualitzar la consola
        {
            lock_guard<mutex> lock(consoleMutex);
            mouCursor(0, animal.fila);
            cout << animal.nom << ": ";
            for (int i = 0; i < animal.posicio; ++i) cout << ".";
            cout.flush();
        }

        // Comprova si ha arribat a la meta
        if (animal.posicio >= META && !haGuanyat.exchange(true)) {
            lock_guard<mutex> lock(consoleMutex);
            mouCursor(0, 10); // Posici� del missatge de guanyador
            cout << "Guanyador: " << animal.nom << " ha arribat a la meta!" << endl;
            return; // Finalitza el fil del guanyador
        }

        this_thread::sleep_for(chrono::milliseconds(100)); // Pausa per simular el moviment
    }
}

int main() {
    // Definim els animals participants
    Animal llebre("Llebre", 3, 2);
    Animal tortuga("Tortuga", 1, 3);
    Animal gos("Gos", 2, 4);

    vector<thread> fils;
    fils.push_back(thread(correAnimal, ref(llebre)));
    fils.push_back(thread(correAnimal, ref(tortuga)));
    fils.push_back(thread(correAnimal, ref(gos)));

    // Esperem que tots els fils finalitzin
    for (auto& fil : fils) {
        fil.join();
    }

    return 0;
}
